
Place screenshots here for GitHub:

examples:
- admin interface
- GPS page
- photobooth UI
