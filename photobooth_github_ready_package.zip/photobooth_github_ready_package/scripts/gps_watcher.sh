
#!/bin/bash

WATCH_DIR="/var/www/html/data/images"
GPS_FILE="/var/www/html/gps.txt"

inotifywait -m -e close_write --format "%f" "$WATCH_DIR" | while read PHOTO
do

FILE="$WATCH_DIR/$PHOTO"

if [ -f "$GPS_FILE" ]; then

LAT=$(cut -d',' -f1 "$GPS_FILE")
LON=$(cut -d',' -f2 "$GPS_FILE")

EVENT="Photobooth Event"

exiftool -GPSLatitude="$LAT" -GPSLongitude="$LON" -GPSLatitudeRef=North -GPSLongitudeRef=East -XMP:Creator="Nicolas SCHEUBEL" -XMP:Software="Photobooth par Nicolas SCHEUBEL" -XMP:Subject="$EVENT" -overwrite_original "$FILE"

fi

done
