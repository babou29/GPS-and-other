
#!/bin/bash

while true
do

if ! gphoto2 --auto-detect | grep -q "Nikon"; then

echo "Camera not detected, resetting USB..."

BUS=$(lsusb | grep Nikon | awk '{print $2}')
DEV=$(lsusb | grep Nikon | awk '{print $4}' | tr -d ':')

if [ ! -z "$BUS" ]; then

echo "$BUS-$DEV" > /sys/bus/usb/drivers/usb/unbind
sleep 2
echo "$BUS-$DEV" > /sys/bus/usb/drivers/usb/bind

fi

fi

sleep 20

done
