
# Photobooth Architecture

Components:

- DSLR Camera (Nikon D3300)
- gphoto2 / cameracontrol.py
- Photobooth PHP application
- Apache web server
- EXIF metadata injection system

Workflow:

1. User presses capture button
2. Photobooth triggers camera via gphoto2
3. Image saved to `/var/www/html/data/images`
4. `gps_watcher.sh` detects new file
5. GPS coordinates inserted via exiftool
