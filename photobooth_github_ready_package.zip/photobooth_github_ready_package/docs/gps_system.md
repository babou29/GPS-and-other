
# GPS System

GPS coordinates are sent from a smartphone browser.

Flow:

Smartphone → admin2.html  
admin2.html → save_gps.php  
save_gps.php → gps.txt

Example gps.txt

01.1234567,-2.1234567


Adds a lightweight mobile admin interface.

Features:

• GPS position upload
• camera shutter counter
• photo counter
• disk usage display