
# Installation commands

Install dependencies

sudo apt install exiftool
sudo apt install inotify-tools
sudo apt install avahi-daemon
sudo apt install usbutils

Enable Avahi

sudo systemctl enable avahi-daemon
sudo systemctl start avahi-daemon

Test mDNS

avahi-resolve-host-name photobooth.local
