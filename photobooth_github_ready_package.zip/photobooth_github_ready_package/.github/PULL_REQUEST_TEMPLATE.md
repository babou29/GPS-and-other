
## Photobooth Enhancement Proposal

### Features added

- GPS EXIF tagging
- Camera watchdog
- Mobile admin tools
- HTTPS local support

### Motivation

Improve stability and metadata support for event photobooths.

### Tested on

Debian 12
Nikon D3300
PhotoboothProject

### Checklist

- [ ] Scripts documented
- [ ] systemd services tested
- [ ] EXIF metadata verified


### Adds a lightweight mobile admin interface.

Features:

• GPS position upload
• camera shutter counter
• photo counter
• disk usage display